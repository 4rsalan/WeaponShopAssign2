﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeaponShopAssignmentGUI
{
    public class Weapon
    {
        public string weaponName { get; set; }
        public int range { get; set; }
        public int damage { get; set; }
        public double weight { get; set; }
        public double cost { get; set; }

        public Weapon(string n, int rang, int dam, double w, double c)
        {
            weaponName = n;
            damage = dam;
            range = rang;
            weight = w;
            cost = c;
        }

        public string toString()
        {
            return "Weapon Name: " + weaponName + "\r\n" + 
                    "Damage: " + damage + "\r\n" + 
                    "Range: " + range + "\r\n" + 
                    "Weight: " + weight + "\r\n" + 
                    "Cost: " + cost + "\r\n";
        }

    }
}
