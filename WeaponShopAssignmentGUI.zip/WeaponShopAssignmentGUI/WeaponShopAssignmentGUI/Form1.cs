﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WeaponShopAssignmentGUI
{
    public partial class FormMain : Form
    {
        string playerName = "";
        FormManageShop FManageShop;
        FormPlayerInfo FPlayerInfo;

        public FormMain()
        {
            InitializeComponent();
        }

        //Loads up the second part of the Main Page
        public void FormLoadUp()
        {
            lblText0.Visible = false;
            txtPlayerName.Visible = false;
            lblConfirm.Visible = false;
            lblText1.Visible = true;
            lblText2.Visible = true;
            lblText3.Visible = true;
            ptbCoin.Visible = true;
            ptbBackpack.Visible = true;
        }

        //The Confirm Button Label
        private void lblConfirm_MouseHover(object sender, EventArgs e)
        {
            lblConfirm.ForeColor = Color.Yellow;
        }

        private void lblConfirm_MouseLeave(object sender, EventArgs e)
        {
            lblConfirm.ForeColor = Color.White;
        }

        private void lblConfirm_Click(object sender, EventArgs e)
        {
            if (txtPlayerName.Text == "")
                lblText0.Text = "You MUST enter a player name:";
            else
                FormLoadUp();
        }
        //

        //The "Manage Player" Button Label
        private void ptbCoin_MouseHover(object sender, EventArgs e)
        {
            lblText2.ForeColor = Color.Yellow;
        }

        private void ptbCoin_MouseLeave(object sender, EventArgs e)
        {
            lblText2.ForeColor = Color.White;
        }

        private void ptbCoin_Click(object sender, EventArgs e)
        {
            FManageShop = new FormManageShop(this);
            FManageShop.Show();
            this.Hide();
        }
        //

        //The "Visit Shop" Button Label
        private void ptbBackpack_MouseHover(object sender, EventArgs e)
        {
            lblText3.ForeColor = Color.Yellow;
        }

        private void ptbBackpack_MouseLeave(object sender, EventArgs e)
        {
            lblText3.ForeColor = Color.White;
        }

        private void ptbBackpack_Click(object sender, EventArgs e)
        {
            FPlayerInfo = new FormPlayerInfo(this);
            FPlayerInfo.Show();
            this.Hide();
        }
        //

        //The Exit Button Label
        private void lblExit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void lblExit_MouseHover(object sender, EventArgs e)
        {
            lblExit.ForeColor = Color.Yellow;
        }

        private void lblExit_MouseLeave(object sender, EventArgs e)
        {
            lblExit.ForeColor = Color.White;
        }
        //

        //When the Form Loads
        private void FormMain_Load(object sender, EventArgs e)
        {
            if (!(playerName == ""))
                FormLoadUp();
        }

        //When Form is forcably closed
        private void FormMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
