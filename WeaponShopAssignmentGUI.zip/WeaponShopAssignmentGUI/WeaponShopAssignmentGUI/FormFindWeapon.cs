﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WeaponShopAssignmentGUI
{
    public partial class FormFindWeapon : Form
    {
        FormMain fMain;
        FormPlayerInfo fPlayerInfo;

        public FormFindWeapon(FormMain F)
        {
            fMain = F;
            InitializeComponent();
        }

        //The Back Button Label
        private void lblBack_MouseHover(object sender, EventArgs e)
        {
            lblBack.ForeColor = Color.Yellow;
        }

        private void lblBack_MouseLeave(object sender, EventArgs e)
        {
            lblBack.ForeColor = Color.White;
        }

        private void lblBack_Click(object sender, EventArgs e)
        {
            fPlayerInfo = new FormPlayerInfo(fMain);
            fPlayerInfo.Show();
            this.Dispose();
        }
        //

        //The Exit Button Label
        private void lblExit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void lblExit_MouseHover(object sender, EventArgs e)
        {
            lblExit.ForeColor = Color.Yellow;
        }

        private void lblExit_MouseLeave(object sender, EventArgs e)
        {
            lblExit.ForeColor = Color.White;
        }
        //

         //The Find Weapon Button Label
        private void lblFindWeapon_Click(object sender, EventArgs e)
        {

        }

        private void lblFindWeapon_MouseHover(object sender, EventArgs e)
        {
            lblFindWeapon.ForeColor = Color.Yellow;
        }

        private void lblFindWeapon_MouseLeave(object sender, EventArgs e)
        {
            lblFindWeapon.ForeColor = Color.White;
        }
        //

        //When the Form is forcably closed
        private void FormFindWeapon_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }
        //
    }
}
